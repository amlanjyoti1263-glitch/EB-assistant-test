# EV Assistant — Android Voice Edition

This project wraps the supplied EV Assistant web app in a native Android WebView.

## Mobile voice support
The APK now uses Android's native:
- `SpeechRecognizer` for microphone input
- `TextToSpeech` for assistant replies
- Runtime `RECORD_AUDIO` permission

This avoids the unreliable `SpeechRecognition` support inside Android WebView.

## GitHub Actions
1. Upload/replace the project files in the repository.
2. Open **Actions**.
3. Run **Build Android APK** (or push to `main`).
4. Wait for the green workflow.
5. Open the successful run and download the `EV-Assistant-APK` artifact.

On the first microphone use, Android will ask for microphone permission. Choose **Allow**.
